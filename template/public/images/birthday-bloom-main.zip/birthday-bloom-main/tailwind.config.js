/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        blush: {
          50: '#fff5f8',
          100: '#ffe9f1',
          200: '#ffd0e0',
          300: '#ffb3cd',
          400: '#ff8db3',
          500: '#ff6b9d',
          600: '#f54789',
          700: '#d62e6f',
          800: '#b01f57',
          900: '#8a1746',
        },
        lavender: {
          50: '#f7f5ff',
          100: '#eee9ff',
          200: '#ddd3ff',
          300: '#c8b6ff',
          400: '#b09bff',
          500: '#9a7dfb',
          600: '#8459e8',
          700: '#6f3fc4',
          800: '#5a2fa0',
          900: '#432275',
        },
        peach: {
          50: '#fff7f2',
          100: '#ffe8db',
          200: '#ffd0b8',
          300: '#ffb38c',
          400: '#ff9466',
          500: '#ff7a45',
          600: '#e85d2a',
          700: '#c4451a',
          800: '#9c3413',
          900: '#7a2810',
        },
        cream: {
          50: '#fffdfb',
          100: '#fff9f3',
          200: '#fff2e6',
          300: '#ffe8d2',
          400: '#ffdab8',
          500: '#ffc89a',
        },
        gold: {
          300: '#ffe89a',
          400: '#ffd966',
          500: '#f5c542',
          600: '#d4a52a',
        },
      },
      fontFamily: {
        display: ['"Fredoka"', 'ui-rounded', 'sans-serif'],
        body: ['"Poppins"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        hand: ['"Caveat"', 'cursive'],
      },
      animation: {
        'float-slow': 'float 6s ease-in-out infinite',
        'float-slower': 'float 9s ease-in-out infinite',
        'twinkle': 'twinkle 3s ease-in-out infinite',
        'drift': 'drift 12s linear infinite',
        'pulse-glow': 'pulseGlow 2.5s ease-in-out infinite',
        'shimmer': 'shimmer 3s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-14px)' },
        },
        twinkle: {
          '0%, 100%': { opacity: '0.2', transform: 'scale(0.8)' },
          '50%': { opacity: '1', transform: 'scale(1.15)' },
        },
        drift: {
          '0%': { transform: 'translateX(-10%) translateY(0)' },
          '100%': { transform: 'translateX(110%) translateY(-20px)' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(255,107,157,0.4), 0 0 40px rgba(184,142,255,0.2)' },
          '50%': { boxShadow: '0 0 35px rgba(255,107,157,0.7), 0 0 70px rgba(184,142,255,0.4)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% center' },
          '100%': { backgroundPosition: '200% center' },
        },
      },
    },
  },
  plugins: [],
};
