import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import OpeningScene from '@/scenes/OpeningScene';
import CountdownScene from '@/scenes/CountdownScene';
import BigRevealScene from '@/scenes/BigRevealScene';
import PickOneScene from '@/scenes/PickOneScene';
import GardenScene from '@/scenes/GardenScene';
import ButterflyScene from '@/scenes/ButterflyScene';
import PhotoScene from '@/scenes/PhotoScene';
import EnvelopeScene from '@/scenes/EnvelopeScene';
import OneMoreThingScene from '@/scenes/OneMoreThingScene';
import GiftScene from '@/scenes/GiftScene';
import CakeScene from '@/scenes/CakeScene';
import FinaleScene from '@/scenes/FinaleScene';
import MusicButton from '@/components/MusicButton';
import EasterEgg from '@/components/EasterEgg';
import DreamyBackground from '@/components/DreamyBackground';
import SceneProgress from '@/components/SceneProgress';
import TapMagic from '@/components/TapMagic';

type Scene =
  | 'opening'
  | 'countdown'
  | 'reveal'
  | 'pickOne'
  | 'garden'
  | 'butterflies'
  | 'photos'
  | 'envelope'
  | 'oneMore'
  | 'gift'
  | 'cake'
  | 'finale';

const order: Scene[] = [
  'opening',
  'countdown',
  'reveal',
  'pickOne',
  'garden',
  'butterflies',
  'photos',
  'envelope',
  'oneMore',
  'gift',
  'cake',
  'finale',
];

export default function App() {
  const [scene, setScene] = useState<Scene>('opening');
  const next = () => {
    const i = order.indexOf(scene);
    if (i < order.length - 1) setScene(order[i + 1]);
  };
  const restart = () => setScene('opening');
  const currentIndex = order.indexOf(scene);

  return (
    <main className="relative min-h-[100dvh] w-full overflow-hidden bg-[#fff4f8]">
      <DreamyBackground />
      <SceneProgress current={currentIndex} total={order.length} />
      <MusicButton />
      <EasterEgg />
      <TapMagic />

      <AnimatePresence mode="wait">
        {scene === 'opening' && <OpeningScene key="opening" onNext={next} />}
        {scene === 'countdown' && <CountdownScene key="countdown" onNext={next} />}
        {scene === 'reveal' && <BigRevealScene key="reveal" onNext={next} />}
        {scene === 'pickOne' && <PickOneScene key="pickOne" onNext={next} />}
        {scene === 'garden' && <GardenScene key="garden" onNext={next} />}
        {scene === 'butterflies' && <ButterflyScene key="butterflies" onNext={next} />}
        {scene === 'photos' && <PhotoScene key="photos" onNext={next} />}
        {scene === 'envelope' && <EnvelopeScene key="envelope" onNext={next} />}
        {scene === 'oneMore' && <OneMoreThingScene key="oneMore" onNext={next} />}
        {scene === 'gift' && <GiftScene key="gift" onNext={next} />}
        {scene === 'cake' && <CakeScene key="cake" onNext={next} />}
        {scene === 'finale' && <FinaleScene key="finale" onRestart={restart} />}
      </AnimatePresence>
    </main>
  );
}
