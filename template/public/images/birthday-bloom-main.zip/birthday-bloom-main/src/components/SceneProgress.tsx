import { motion } from 'framer-motion';

type Props = { current: number; total: number };

export default function SceneProgress({ current, total }: Props) {
  if (current <= 0 || current >= total - 1) return null;

  return (
    <div className="pointer-events-none fixed bottom-4 left-1/2 z-50 w-[min(220px,calc(100vw-48px))] -translate-x-1/2">
      <div className="dream-progress-track">
        <motion.div
          className="dream-progress-fill"
          initial={{ width: 0 }}
          animate={{ width: `${(current / (total - 1)) * 100}%` }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
        />
      </div>
      <p className="mt-1 text-center font-body text-[10px] font-medium tracking-[0.2em] text-rose-500/55">
        {current} / {total - 1}
      </p>
    </div>
  );
}
