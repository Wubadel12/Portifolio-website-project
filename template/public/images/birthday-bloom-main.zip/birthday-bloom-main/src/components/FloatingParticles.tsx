import { useMemo } from 'react';
import { motion } from 'framer-motion';

// Deterministic pseudo-random so particles don't jump around on re-render
function seeded(n: number) {
  const x = Math.sin(n * 999.13) * 10000;
  return x - Math.floor(x);
}

type Particle = {
  left: number;
  top: number;
  size: number;
  delay: number;
  duration: number;
  drift: number;
  emoji: string;
};

const EMOJIS = ['✨', '🌸', '🦋', '💫', '🎀', '⭐', '🌷'];

/** Floating ambient particles (sparkles, petals, butterflies) for any scene. */
export default function FloatingParticles({
  count = 14,
  emojis = EMOJIS,
  className = '',
}: {
  count?: number;
  emojis?: string[];
  className?: string;
}) {
  const particles = useMemo<Particle[]>(
    () =>
      Array.from({ length: count }, (_, i) => ({
        left: seeded(i + 1) * 100,
        top: seeded(i + 7) * 100,
        size: 10 + seeded(i + 3) * 16,
        delay: seeded(i + 5) * 6,
        duration: 7 + seeded(i + 2) * 8,
        drift: (seeded(i + 4) - 0.5) * 40,
        emoji: emojis[i % emojis.length],
      })),
    [count, emojis],
  );

  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      {particles.map((p, i) => (
        <motion.span
          key={i}
          className="absolute select-none"
          style={{ left: `${p.left}%`, top: `${p.top}%`, fontSize: p.size }}
          initial={{ opacity: 0, y: 0 }}
          animate={{
            opacity: [0, 0.9, 0],
            y: [0, -60, -120],
            x: [0, p.drift, 0],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          {p.emoji}
        </motion.span>
      ))}
    </div>
  );
}
