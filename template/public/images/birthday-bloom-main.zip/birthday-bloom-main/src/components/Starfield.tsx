import { useMemo } from 'react';
import { motion } from 'framer-motion';

function seeded(n: number) {
  const x = Math.sin(n * 137.507) * 10000;
  return x - Math.floor(x);
}

type Star = {
  left: number;
  top: number;
  size: number;
  delay: number;
};

/** Twinkling starfield background — works on light or dark scenes. */
export default function Starfield({
  count = 40,
  color = 'white',
  className = '',
}: {
  count?: number;
  color?: string;
  className?: string;
}) {
  const stars = useMemo<Star[]>(
    () =>
      Array.from({ length: count }, (_, i) => ({
        left: seeded(i + 1) * 100,
        top: seeded(i + 11) * 100,
        size: 1.5 + seeded(i + 3) * 3,
        delay: seeded(i + 5) * 4,
      })),
    [count],
  );

  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      {stars.map((s, i) => (
        <motion.span
          key={i}
          className="absolute rounded-full"
          style={{
            left: `${s.left}%`,
            top: `${s.top}%`,
            width: s.size,
            height: s.size,
            background: color,
            boxShadow: `0 0 ${s.size * 3}px ${color}`,
          }}
          animate={{ opacity: [0.15, 1, 0.15], scale: [0.7, 1.2, 0.7] }}
          transition={{ duration: 3, delay: s.delay, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
    </div>
  );
}
