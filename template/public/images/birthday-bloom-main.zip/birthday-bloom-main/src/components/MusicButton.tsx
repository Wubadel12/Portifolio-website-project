import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Music2, VolumeX } from 'lucide-react';
import { content } from '@/content';

/** Floating music toggle. Never autoplays — user must tap to start. */
export default function MusicButton() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [enabled, setEnabled] = useState(Boolean(content.music.url));

  useEffect(() => {
    if (!content.music.url) return;
    const audio = new Audio(content.music.url);
    audio.loop = true;
    audio.volume = 0.5;
    audio.preload = 'none';
    audioRef.current = audio;
    setEnabled(true);
    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, []);

  const toggle = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
    } else {
      audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
  };

  if (!enabled) return null;

  return (
    <motion.button
      onClick={toggle}
      aria-label={playing ? 'Pause music' : content.music.label}
      className="fixed top-4 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-full glass shadow-lg no-select"
      whileTap={{ scale: 0.9 }}
      whileHover={{ scale: 1.05 }}
    >
      <AnimatePresence mode="wait">
        {playing ? (
          <motion.span
            key="on"
            initial={{ scale: 0, rotate: -90 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 90 }}
            className="text-blush-500"
          >
            <Music2 size={22} />
          </motion.span>
        ) : (
          <motion.span
            key="off"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            className="text-lavender-500"
          >
            <VolumeX size={22} />
          </motion.span>
        )}
      </AnimatePresence>
      {playing && (
        <motion.span
          className="absolute inset-0 rounded-full border-2 border-blush-400"
          animate={{ scale: [1, 1.4], opacity: [0.7, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut' }}
        />
      )}
    </motion.button>
  );
}
