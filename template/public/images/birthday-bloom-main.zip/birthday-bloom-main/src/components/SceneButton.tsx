import { motion } from 'framer-motion';
import { ReactNode } from 'react';

/** Reusable glowing pill button used across scenes. */
export default function SceneButton({
  children,
  onClick,
  className = '',
  variant = 'light',
}: {
  children: ReactNode;
  onClick: () => void;
  className?: string;
  variant?: 'light' | 'dark' | 'gold';
}) {
  const styles = {
    light: 'bg-white/90 text-blush-600 shadow-[0_8px_30px_rgba(255,107,157,0.35)]',
    dark: 'bg-white/15 text-white border border-white/30 shadow-[0_8px_30px_rgba(0,0,0,0.3)]',
    gold: 'bg-gradient-to-r from-gold-400 to-blush-400 text-white shadow-[0_8px_30px_rgba(245,197,66,0.4)]',
  }[variant];

  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.94 }}
      whileHover={{ scale: 1.04 }}
      className={`dream-button relative flex items-center justify-center gap-2 rounded-full font-display tracking-wide no-select ${styles} ${className}`}
    >
      {children}
    </motion.button>
  );
}
