import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

type Spark = { id: number; x: number; y: number; symbol: string; size: number };
const symbols = ['✦', '♡', '✧', '·', '✿'];

export default function TapMagic() {
  const [sparks, setSparks] = useState<Spark[]>([]);

  useEffect(() => {
    let nextId = 0;
    const handlePointer = (event: PointerEvent) => {
      const base = nextId;
      nextId += 6;
      const created = Array.from({ length: 6 }, (_, i) => ({
        id: base + i,
        x: event.clientX + (Math.random() - 0.5) * 30,
        y: event.clientY + (Math.random() - 0.5) * 24,
        symbol: symbols[(base + i) % symbols.length],
        size: 11 + Math.random() * 10,
      }));

      setSparks((current) => [...current.slice(-24), ...created]);
      window.setTimeout(() => {
        setSparks((current) => current.filter((spark) => !created.some((item) => item.id === spark.id)));
      }, 850);
    };

    window.addEventListener('pointerdown', handlePointer, { passive: true });
    return () => window.removeEventListener('pointerdown', handlePointer);
  }, []);

  return (
    <div className="pointer-events-none fixed inset-0 z-[70] overflow-hidden" aria-hidden="true">
      <AnimatePresence>
        {sparks.map((spark) => (
          <motion.span
            key={spark.id}
            className="absolute font-display text-rose-400/75 drop-shadow-[0_0_10px_rgba(255,130,180,0.5)]"
            style={{ left: spark.x, top: spark.y, fontSize: spark.size }}
            initial={{ opacity: 0, scale: 0.3, x: 0, y: 0, rotate: 0 }}
            animate={{ opacity: [0, 1, 0], scale: [0.3, 1.15, 0.75], x: (Math.random() - 0.5) * 44, y: -42 - Math.random() * 30, rotate: (Math.random() - 0.5) * 70 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.75, ease: 'easeOut' }}
          >
            {spark.symbol}
          </motion.span>
        ))}
      </AnimatePresence>
    </div>
  );
}
