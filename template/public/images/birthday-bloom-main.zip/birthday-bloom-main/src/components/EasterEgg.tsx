import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star } from 'lucide-react';
import { content } from '@/content';

/** A tiny star in the corner. Tap it 5 times to reveal a secret. */
export default function EasterEgg() {
  const [taps, setTaps] = useState(0);
  const [revealed, setRevealed] = useState(false);

  const handleTap = () => {
    if (revealed) return;
    const next = taps + 1;
    setTaps(next);
    if (next >= 5) setRevealed(true);
  };

  return (
    <>
      <motion.button
        onClick={handleTap}
        aria-label="a tiny star"
        className="fixed bottom-3 left-3 z-40 text-white/40 hover:text-white/70 no-select"
        whileTap={{ scale: 0.8 }}
        animate={{ rotate: taps * 8 }}
      >
        <Star size={14} fill="currentColor" />
      </motion.button>

      <AnimatePresence>
        {revealed && (
          <motion.div
            className="fixed inset-0 z-[60] flex items-center justify-center p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 bg-[#1a1030]/80 backdrop-blur-sm" onClick={() => setRevealed(false)} />
            <motion.div
              className="relative max-w-sm rounded-3xl bg-white/95 p-7 text-center shadow-2xl"
              initial={{ scale: 0.7, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.7, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 20 }}
            >
              <div className="mb-2 text-3xl">✨</div>
              <p className="font-display text-xl text-blush-600">{content.easterEgg.found}</p>
              <p className="mt-3 font-body text-sm text-gray-600">{content.easterEgg.message}</p>
              <button
                onClick={() => setRevealed(false)}
                className="mt-5 rounded-full bg-blush-500 px-6 py-2 font-display text-sm text-white shadow-md"
              >
                Close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
