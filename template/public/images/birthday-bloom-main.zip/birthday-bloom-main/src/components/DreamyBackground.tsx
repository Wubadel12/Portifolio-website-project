import { motion } from 'framer-motion';

const hearts = [
  { left: '8%', top: '20%', size: 16, delay: 0, duration: 8 },
  { left: '82%', top: '16%', size: 12, delay: 1.4, duration: 9 },
  { left: '14%', top: '72%', size: 11, delay: 2.2, duration: 10 },
  { left: '88%', top: '70%', size: 18, delay: 0.8, duration: 8.5 },
  { left: '52%', top: '8%', size: 10, delay: 3, duration: 11 },
];

const petals = [
  { left: '4%', top: '44%', rotate: -18, delay: 0 },
  { left: '91%', top: '38%', rotate: 24, delay: 1.5 },
  { left: '74%', top: '82%', rotate: -34, delay: 2.5 },
  { left: '23%', top: '12%', rotate: 18, delay: 3.2 },
];

export default function DreamyBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
      <div className="dream-aurora dream-aurora-one" />
      <div className="dream-aurora dream-aurora-two" />
      <div className="dream-aurora dream-aurora-three" />
      <div className="dream-moon-glow" />

      <div className="absolute inset-0 opacity-70">
        {hearts.map((heart, i) => (
          <motion.span
            key={`heart-${i}`}
            className="absolute text-rose-300/60"
            style={{ left: heart.left, top: heart.top, fontSize: heart.size }}
            animate={{ y: [0, -18, 0], x: [0, i % 2 ? 8 : -8, 0], opacity: [0.25, 0.8, 0.25], rotate: [-8, 8, -8] }}
            transition={{ duration: heart.duration, delay: heart.delay, repeat: Infinity, ease: 'easeInOut' }}
          >
            ♥
          </motion.span>
        ))}
      </div>

      {petals.map((petal, i) => (
        <motion.span
          key={`petal-${i}`}
          className="absolute h-3 w-2 rounded-full bg-white/50 shadow-[0_0_12px_rgba(255,255,255,0.8)]"
          style={{ left: petal.left, top: petal.top, rotate: petal.rotate }}
          animate={{ y: [0, 80, 160], x: [0, i % 2 ? -35 : 35, i % 2 ? -15 : 15], opacity: [0, 0.7, 0] }}
          transition={{ duration: 9 + i, delay: petal.delay, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
    </div>
  );
}
