import confetti from 'canvas-confetti';

const dreamColors = ['#ff6b9d', '#b88eff', '#ffb38c', '#ffd966', '#ffffff'];

/** A gentle, dreamy confetti burst — not chaotic. */
export function dreamBurst(originX = 0.5, originY = 0.5) {
  confetti({
    particleCount: 50,
    spread: 70,
    startVelocity: 35,
    origin: { x: originX, y: originY },
    colors: dreamColors,
    scalar: 0.9,
    ticks: 160,
    disableForReducedMotion: true,
  });
}

/** Full-screen celebration for the big reveal. */
export function bigCelebration() {
  const end = Date.now() + 1200;
  (function frame() {
    confetti({
      particleCount: 4,
      angle: 60,
      spread: 55,
      origin: { x: 0, y: 0.7 },
      colors: dreamColors,
      disableForReducedMotion: true,
    });
    confetti({
      particleCount: 4,
      angle: 120,
      spread: 55,
      origin: { x: 1, y: 0.7 },
      colors: dreamColors,
      disableForReducedMotion: true,
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();

  confetti({
    particleCount: 120,
    spread: 100,
    startVelocity: 45,
    origin: { x: 0.5, y: 0.5 },
    colors: dreamColors,
    scalar: 1.1,
    disableForReducedMotion: true,
  });
}

/** Fireworks-style burst from a point. */
export function firework(x: number, y: number) {
  confetti({
    particleCount: 30,
    spread: 360,
    startVelocity: 30,
    origin: { x, y },
    colors: dreamColors,
    scalar: 0.8,
    ticks: 120,
    disableForReducedMotion: true,
  });
}
