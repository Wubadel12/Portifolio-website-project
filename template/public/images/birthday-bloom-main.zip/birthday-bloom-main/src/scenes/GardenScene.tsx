import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';

// SVG flower component — blooms on tap
function Flower({
  color,
  bloom,
  onClick,
  delay,
  rotate,
}: {
  color: string;
  bloom: boolean;
  onClick: () => void;
  delay: number;
  rotate: number;
}) {
  return (
    <motion.button
      onClick={onClick}
      className="relative flex h-20 w-20 items-center justify-center no-select sm:h-24 sm:w-24"
      initial={{ opacity: 0, scale: 0.3, y: 30 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay, type: 'spring', stiffness: 160, damping: 14 }}
      whileTap={{ scale: 0.9 }}
    >
      <motion.svg
        viewBox="0 0 100 100"
        className="h-full w-full"
        animate={{ rotate: bloom ? rotate + 8 : rotate }}
        transition={{ type: 'spring', stiffness: 120 }}
      >
        {/* Petals */}
        {[0, 72, 144, 216, 288].map((angle) => (
          <motion.ellipse
            key={angle}
            cx="50"
            cy="28"
            rx="14"
            ry="22"
            fill={color}
            transform={`rotate(${angle} 50 50)`}
            initial={{ scale: 0 }}
            animate={{ scale: bloom ? 1 : 0.25 }}
            transition={{ type: 'spring', stiffness: 200, damping: 12 }}
            style={{ transformOrigin: '50px 50px' }}
          />
        ))}
        {/* Center */}
        <circle cx="50" cy="50" r="10" fill="#ffd966" />
      </motion.svg>
    </motion.button>
  );
}

const FLOWER_COLORS = ['#ff6b9d', '#b88eff', '#ffb38c', '#ff8db3', '#c8b6ff', '#ffa07a'];

export default function GardenScene({ onNext }: { onNext: () => void }) {
  const [bloomed, setBloomed] = useState<number[]>([]);
  const [message, setMessage] = useState<string | null>(null);

  const toggle = (i: number) => {
    setBloomed((prev) => (prev.includes(i) ? prev : [...prev, i]));
    setMessage(content.garden.flowers[i].message);
  };

  return (
    <motion.div
      className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden dream-scene dream-peach"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={8} emojis={['🌸', '🌷', '✨']} />

      <div className="relative z-10 text-center">
        <motion.p
          className="font-display text-2xl text-rose-700 sm:text-3xl"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {content.garden.title} 🌸
        </motion.p>

        <div className="mt-10 grid grid-cols-3 gap-4 sm:gap-6">
          {content.garden.flowers.map((_, i) => (
            <Flower
              key={i}
              color={FLOWER_COLORS[i % FLOWER_COLORS.length]}
              bloom={bloomed.includes(i)}
              onClick={() => toggle(i)}
              delay={0.2 + i * 0.1}
              rotate={(i % 2 === 0 ? 1 : -1) * 5}
            />
          ))}
        </div>

        <AnimatePresence>
          {message && (
            <motion.div
              key={message}
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ type: 'spring', stiffness: 200, damping: 18 }}
              className="mt-8"
            >
              <div className="rounded-2xl bg-white/80 px-6 py-4 shadow-lg backdrop-blur-sm">
                <p className="font-hand text-2xl text-rose-700">{message}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {bloomed.length >= 3 && (
          <motion.div
            className="mt-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <SceneButton onClick={onNext}>
              {content.garden.button} →
            </SceneButton>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
