import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';

export default function PickOneScene({ onNext }: { onNext: () => void }) {
  const [picked, setPicked] = useState<number | null>(null);

  return (
    <motion.div
      className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden dream-scene dream-cream"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={10} emojis={['✨', '🌸', '🦋']} />

      <div className="relative z-10 text-center">
        <motion.p
          className="font-body text-base text-purple-800/80"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {content.pickOne.intro}
        </motion.p>
        <motion.p
          className="mt-2 font-display text-2xl text-rose-700 sm:text-3xl"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          {content.pickOne.prompt} ✨
        </motion.p>

        <div className="mt-10 flex items-center justify-center gap-4 sm:gap-6">
          {content.pickOne.cards.map((card, i) => (
            <motion.button
              key={i}
              onClick={() => setPicked(i)}
              disabled={picked !== null}
              className="relative flex h-28 w-24 items-center justify-center rounded-3xl bg-white/70 shadow-xl backdrop-blur-sm no-select sm:h-36 sm:w-32"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 + i * 0.15, type: 'spring', stiffness: 200 }}
              whileTap={{ scale: 0.92 }}
              whileHover={{ scale: 1.05, rotate: i === 1 ? 0 : i === 0 ? -3 : 3 }}
              style={{ rotate: i === 1 ? 0 : i === 0 ? -4 : 4 }}
            >
              <span className="text-4xl sm:text-5xl">{card.emoji}</span>
            </motion.button>
          ))}
        </div>

        <AnimatePresence>
          {picked !== null && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ type: 'spring', stiffness: 200, damping: 18 }}
              className="mt-8"
            >
              <div className="rounded-2xl bg-white/80 px-6 py-5 shadow-lg backdrop-blur-sm">
                <p className="font-hand text-2xl text-rose-700 sm:text-3xl">
                  {content.pickOne.cards[picked].message}
                </p>
              </div>
              <div className="mt-8">
                <SceneButton onClick={onNext}>
                  {content.pickOne.button} →
                </SceneButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
