import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';

export default function OneMoreThingScene({ onNext }: { onNext: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const delays = [600, 1400, 2200, 3000, 3800];
    if (step < delays.length) {
      const t = setTimeout(() => setStep((s) => s + 1), delays[step]);
      return () => clearTimeout(t);
    }
  }, [step]);

  const lines = [
    content.oneMoreThing.okay,
    content.oneMoreThing.thatsAll,
    content.oneMoreThing.dots,
    content.oneMoreThing.actuallyNo,
    content.oneMoreThing.oneMore,
  ];

  return (
    <motion.div
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden dream-scene dream-lilac"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={6} emojis={['✨', '👀', '💫']} />

      <div className="relative z-10 text-center">
        <AnimatePresence mode="wait">
          {step < lines.length ? (
            <motion.p
              key={step}
              className="font-display text-2xl text-blush-600 sm:text-3xl"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4 }}
            >
              {lines[step]}
            </motion.p>
          ) : (
            <motion.div
              key="button"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 14 }}
            >
              <p className="mb-8 font-display text-2xl text-blush-600">
                {content.oneMoreThing.oneMore} 👀
              </p>
              <SceneButton onClick={onNext} variant="gold">
                {content.oneMoreThing.button}
              </SceneButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
