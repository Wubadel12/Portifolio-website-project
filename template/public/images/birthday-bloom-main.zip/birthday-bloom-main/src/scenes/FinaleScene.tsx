import { motion } from 'framer-motion';
import { content } from '@/content';
import Starfield from '@/components/Starfield';
import FloatingParticles from '@/components/FloatingParticles';
import { firework } from '@/components/confetti';

export default function FinaleScene({ onRestart }: { onRestart: () => void }) {
  const handleFirework = (e: React.MouseEvent) => {
    firework(e.clientX / window.innerWidth, e.clientY / window.innerHeight);
  };

  return (
    <motion.div
      className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden dream-scene dream-night"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
      onClick={handleFirework}
    >
      <Starfield count={80} color="white" />
      <FloatingParticles count={14} emojis={['✨', '⭐', '💫', '🌟']} />

      {/* Moon */}
      <motion.div
        className="absolute right-8 top-16 h-20 w-20 rounded-full bg-gradient-to-br from-cream-100 to-cream-300 shadow-[0_0_60px_rgba(255,242,230,0.4)]"
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="relative z-10 text-center">
        <motion.p
          className="font-display text-3xl text-white sm:text-5xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          {content.finale.happyBirthday}
        </motion.p>
        <motion.p
          className="mt-2 font-hand text-5xl text-gradient-gold sm:text-6xl"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2, type: 'spring', stiffness: 150 }}
        >
          {content.name} 💕
        </motion.p>

        <motion.p
          className="mt-10 font-display text-xl text-white/90 sm:text-2xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.5, duration: 0.6 }}
        >
          {content.finale.welcomeTo}
        </motion.p>

        <motion.p
          className="mt-4 max-w-sm font-body text-sm text-white/70 sm:text-base"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 3.5, duration: 0.6 }}
        >
          {content.finale.hopeLine}
        </motion.p>

        <motion.p
          className="mt-6 font-hand text-2xl text-blush-300 sm:text-3xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 4.5, duration: 0.6 }}
        >
          {content.finale.enjoyLine} 🎀
        </motion.p>

        <motion.p
          className="mt-12 font-body text-xs text-white/40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 6, duration: 0.6 }}
        >
          {content.finale.madeFor}
        </motion.p>

        <motion.button
          onClick={(e) => {
            e.stopPropagation();
            onRestart();
          }}
          className="mt-8 rounded-full border border-white/20 px-6 py-2 font-body text-xs text-white/60 no-select"
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 7 }}
        >
          replay the surprise
        </motion.button>
      </div>
    </motion.div>
  );
}
