import { motion } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import Starfield from '@/components/Starfield';
import SceneButton from '@/components/SceneButton';
import { dreamBurst } from '@/components/confetti';

export default function CountdownScene({ onNext }: { onNext: () => void }) {
  return (
    <motion.div
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden dream-scene dream-lilac"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.6 }}
    >
      <Starfield count={20} color="rgba(184,142,255,0.8)" />
      <FloatingParticles count={8} emojis={['✨', '💫', '⭐']} />

      <div className="relative z-10 text-center">
        <motion.p
          className="font-display text-2xl text-purple-800/80"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          {content.countdown.wait}
        </motion.p>

        <motion.p
          className="mt-3 font-body text-base text-rose-700/80"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3, duration: 0.5 }}
        >
          {content.countdown.almostForgot}
        </motion.p>

        {/* The big age reveal */}
        <motion.div
          className="my-8"
          initial={{ opacity: 0, scale: 0.3 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 2.6, type: 'spring', stiffness: 200, damping: 12 }}
          onAnimationComplete={() => dreamBurst(0.5, 0.45)}
        >
          <span className="font-display text-[7rem] font-bold leading-none text-gradient-dream drop-shadow-[0_0_40px_rgba(255,107,157,0.5)] sm:text-[9rem]">
            {content.age}
          </span>
          <motion.p
            className="mt-2 font-display text-xl text-rose-700 sm:text-2xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 3.2, duration: 0.5 }}
          >
            {content.countdown.reveal}
          </motion.p>
        </motion.div>

        <motion.p
          className="font-body text-sm text-purple-800/80"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 4, duration: 0.5 }}
        >
          {content.countdown.nowStart}
        </motion.p>

        <motion.div
          className="mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 4.8, duration: 0.5 }}
        >
          <SceneButton onClick={onNext}>
            {content.countdown.button} →
          </SceneButton>
        </motion.div>
      </div>
    </motion.div>
  );
}
