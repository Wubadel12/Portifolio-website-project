import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import SceneButton from '@/components/SceneButton';
import Starfield from '@/components/Starfield';

type Butterfly = {
  id: number;
  x: number;
  y: number;
  duration: number;
  delay: number;
  color: string;
};

const COLORS = ['#ff6b9d', '#b88eff', '#ffb38c', '#c8b6ff', '#ff8db3'];

function ButterflySVG({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 64 48" className="h-16 w-20 drop-shadow-[0_8px_12px_rgba(120,70,130,0.25)] sm:h-20 sm:w-28">
      <ellipse cx="20" cy="16" rx="14" ry="12" fill={color} opacity="0.85" />
      <ellipse cx="44" cy="16" rx="14" ry="12" fill={color} opacity="0.85" />
      <ellipse cx="22" cy="34" rx="10" ry="9" fill={color} opacity="0.7" />
      <ellipse cx="42" cy="34" rx="10" ry="9" fill={color} opacity="0.7" />
      <rect x="31" y="8" width="2" height="32" rx="1" fill="#4a3a5a" />
      <circle cx="32" cy="8" r="2.5" fill="#4a3a5a" />
    </svg>
  );
}

export default function ButterflyScene({ onNext }: { onNext: () => void }) {
  const [caught, setCaught] = useState<number[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const msgIndex = useRef(0);
  const [butterflies] = useState<Butterfly[]>(() =>
    Array.from({ length: 6 }, (_, i) => ({
      id: i,
      x: 8 + Math.random() * 76,
      y: 20 + Math.random() * 58,
      duration: 8 + Math.random() * 6,
      delay: Math.random() * 3,
      color: COLORS[i % COLORS.length],
    })),
  );

  const catchButterfly = (id: number) => {
    if (caught.includes(id)) return;
    setCaught([...caught, id]);
    setMessage(content.butterflies.messages[msgIndex.current % content.butterflies.messages.length]);
    msgIndex.current++;
  };

  return (
    <motion.div
      className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden dream-scene dream-lilac"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Starfield count={15} color="rgba(184,142,255,0.5)" />

      <div className="relative z-10 text-center">
        <motion.p
          className="font-display text-3xl font-semibold text-purple-800 drop-shadow-sm sm:text-4xl"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {content.butterflies.prompt}
        </motion.p>
      </div>

      {/* Flying butterflies */}
      <div className="absolute inset-0 z-0">
        {butterflies.map((b) => (
          <motion.button
            key={b.id}
            onClick={() => catchButterfly(b.id)}
            disabled={caught.includes(b.id)}
            className="absolute flex h-20 w-20 items-center justify-center rounded-full bg-white/10 no-select backdrop-blur-[2px] sm:h-28 sm:w-28"
            style={{ left: `${b.x}%`, top: `${b.y}%` }}
            initial={{ x: -50, opacity: 0 }}
            animate={
              caught.includes(b.id)
                ? { scale: 0, opacity: 0, y: -40 }
                : {
                    x: [0, 80, -40, 60, 0],
                    y: [0, -30, 20, -10, 0],
                    opacity: 1,
                  }
            }
            transition={
              caught.includes(b.id)
                ? { duration: 0.5 }
                : { duration: b.duration, delay: b.delay, repeat: Infinity, ease: 'easeInOut' }
            }
            whileTap={{ scale: 1.3 }}
          >
            <motion.div animate={{ rotate: [-5, 5, -5] }} transition={{ duration: 0.4, repeat: Infinity }}>
              <ButterflySVG color={b.color} />
            </motion.div>
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {message && (
          <motion.div
            key={message + msgIndex.current}
            initial={{ opacity: 0, y: 30, scale: 0.7 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ type: 'spring', stiffness: 200, damping: 18 }}
            className="absolute bottom-24 z-20"
          >
            <div className="romantic-card rounded-3xl px-6 py-4 shadow-xl">
              <p className="font-hand text-2xl font-semibold text-rose-700 sm:text-3xl">✨ {message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {caught.length >= 2 && (
        <motion.div
          className="absolute bottom-8 z-20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <SceneButton onClick={onNext}>
            {content.butterflies.button} →
          </SceneButton>
        </motion.div>
      )}
    </motion.div>
  );
}
