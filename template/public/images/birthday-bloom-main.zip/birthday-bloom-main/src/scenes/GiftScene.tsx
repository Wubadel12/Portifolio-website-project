import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';
import { dreamBurst } from '@/components/confetti';

export default function GiftScene({ onNext }: { onNext: () => void }) {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden dream-scene dream-rose"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={10} emojis={['✨', '🎁', '💫', '🎀']} />

      <div className="relative z-10 w-full max-w-md text-center">
        <motion.p
          className="font-display text-3xl font-semibold text-rose-700 drop-shadow-sm sm:text-4xl"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {content.gift.label} 🎁
        </motion.p>

        <p className="mt-2 font-body text-sm font-medium text-purple-900/65 sm:text-base">There’s one little surprise waiting inside.</p>

        {/* Gift box */}
        <div className="relative mt-10 flex justify-center">
          <motion.button
            onClick={() => {
              setOpen(true);
              dreamBurst(0.5, 0.5);
            }}
            disabled={open}
            className="relative no-select"
            whileTap={{ scale: 0.92 }}
            whileHover={{ scale: 1.05 }}
            animate={open ? {} : { y: [0, -6, 0] }}
            transition={open ? {} : { duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            {/* Box body */}
            <div className="relative h-36 w-36 sm:h-44 sm:w-44">
              <div className="absolute bottom-0 h-32 w-full rounded-lg bg-gradient-to-b from-blush-400 to-blush-500 shadow-xl sm:h-40" />
              {/* Lid */}
              <motion.div
                className="absolute left-0 top-0 h-10 w-full rounded-lg bg-gradient-to-b from-blush-300 to-blush-400 shadow-md sm:h-12"
                animate={open ? { y: -50, rotate: -15, opacity: 0 } : { y: 0 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
              />
              {/* Vertical ribbon */}
              <div className="absolute left-1/2 top-0 h-full w-5 -translate-x-1/2 bg-gold-400" />
              {/* Horizontal ribbon */}
              <div className="absolute left-0 top-4 h-5 w-full bg-gold-400 sm:top-5" />
              {/* Bow */}
              <motion.div
                className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 text-3xl"
                animate={open ? { y: -60, opacity: 0, scale: 0 } : { y: 0, opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
              >
                🎀
              </motion.div>
              {/* Glow */}
              {!open && (
                <motion.div
                  className="absolute inset-0 rounded-lg"
                  animate={{ boxShadow: ['0 0 20px rgba(255,107,157,0.3)', '0 0 40px rgba(255,107,157,0.6)', '0 0 20px rgba(255,107,157,0.3)'] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
            </div>
          </motion.button>

          {/* Sparkle burst on open */}
          <AnimatePresence>
            {open && (
              <motion.div
                className="pointer-events-none absolute inset-0 flex items-center justify-center"
                initial={{ scale: 0 }}
                animate={{ scale: 2, opacity: 0 }}
                transition={{ duration: 0.8 }}
              >
                <span className="text-6xl">✨</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.3, type: 'spring', stiffness: 160, damping: 18 }}
              className="romantic-card mt-8 rounded-3xl p-6 shadow-2xl"
            >
              <pre className="whitespace-pre-wrap font-body text-sm leading-relaxed text-gray-700">
                {content.gift.surprise}
              </pre>
              <div className="mt-6">
                <SceneButton onClick={onNext}>
                  {content.gift.button} →
                </SceneButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
