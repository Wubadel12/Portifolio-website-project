import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';

export default function EnvelopeScene({ onNext }: { onNext: () => void }) {
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden dream-scene dream-peach"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={8} emojis={['✨', '💌', '💫']} />

      <div className="relative z-10 w-full max-w-md text-center">
        <motion.p
          className="font-display text-3xl font-semibold text-rose-700 drop-shadow-sm sm:text-4xl"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {content.envelope.prompt}
        </motion.p>

        {/* Envelope */}
        <div className="relative mt-10 flex justify-center">
          <motion.button
            onClick={() => setOpen(true)}
            disabled={open}
            className="relative no-select"
            whileTap={{ scale: 0.95 }}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 16 }}
          >
            {/* Envelope body */}
            <div className="relative h-32 w-56 overflow-hidden rounded-lg bg-gradient-to-b from-blush-200 to-blush-300 shadow-xl sm:h-40 sm:w-72">
              {/* Flap */}
              <motion.div
                className="absolute left-0 top-0 h-0 w-full"
                style={{
                  borderLeft: '112px solid transparent',
                  borderRight: '112px solid transparent',
                  borderTop: '64px solid #ffd0e0',
                  transformOrigin: 'top',
                }}
                animate={{ rotateX: open ? 180 : 0 }}
                transition={{ duration: 0.6, ease: 'easeInOut' }}
              />
              {!open && (
                <motion.div
                  className="pointer-events-none absolute inset-0 flex items-center justify-center"
                >
                  <span className="rounded-full bg-white/55 px-4 py-2 font-display text-sm font-semibold text-rose-700 shadow-sm backdrop-blur-sm">💌 ready when you are</span>
                </motion.div>
              )}
            </div>
          </motion.button>
        </div>

        {!open && (
          <motion.div
            className="mt-7"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
          >
            <SceneButton onClick={() => setOpen(true)} variant="gold">
              Open the letter 💌
            </SceneButton>
          </motion.div>
        )}

        {/* Letter */}
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.4, type: 'spring', stiffness: 160, damping: 18 }}
              className="romantic-card mt-8 rounded-3xl p-6 text-left shadow-2xl"
            >
              <pre className="whitespace-pre-wrap font-body text-sm leading-relaxed text-rose-950/80">
                {content.envelope.letter}
              </pre>
              <div className="mt-6 text-center">
                <SceneButton onClick={onNext}>
                  {content.envelope.button} →
                </SceneButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
