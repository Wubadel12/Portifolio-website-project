import { motion } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import Starfield from '@/components/Starfield';
import SceneButton from '@/components/SceneButton';

export default function OpeningScene({ onNext }: { onNext: () => void }) {
  return (
    <motion.div
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden dream-scene dream-rose"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1, filter: 'blur(8px)' }}
      transition={{ duration: 0.8 }}
    >
      {/* Soft glowing orbs */}
      <div className="pointer-events-none absolute -top-20 -left-10 h-72 w-72 rounded-full bg-blush-300/40 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-80 w-80 rounded-full bg-lavender-300/40 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 right-10 h-48 w-48 rounded-full bg-peach-300/40 blur-3xl" />

      <Starfield count={30} color="rgba(255,255,255,0.9)" />
      <FloatingParticles count={12} />

      <div className="relative z-10 text-center">
        <motion.p
          className="font-display text-3xl text-rose-700 sm:text-4xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
        >
          {content.opening.greeting}
        </motion.p>

        <motion.p
          className="mt-4 font-body text-lg text-purple-800 sm:text-xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.7 }}
        >
          {content.opening.subgreeting}
        </motion.p>

        <motion.div
          className="mt-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.4, duration: 0.7 }}
        >
          <SceneButton onClick={onNext} variant="gold">
            ✨ {content.opening.button}
          </SceneButton>
        </motion.div>
      </div>
    </motion.div>
  );
}
