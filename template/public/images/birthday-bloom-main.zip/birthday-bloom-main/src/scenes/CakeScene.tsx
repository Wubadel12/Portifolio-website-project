import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import Starfield from '@/components/Starfield';
import SceneButton from '@/components/SceneButton';

// A single candle with flame
function Candle({
  lit,
  onToggle,
  index,
}: {
  lit: boolean;
  onToggle: () => void;
  index: number;
}) {
  return (
    <button onClick={onToggle} className="relative flex flex-col items-center no-select" aria-label={`candle ${index + 1}`}>
      {/* Flame */}
      <AnimatePresence>
        {lit && (
          <motion.span
            className="mb-0.5 text-sm"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
          >
            🔥
          </motion.span>
        )}
      </AnimatePresence>
      {/* Wick smoke when out */}
      <AnimatePresence>
        {!lit && (
          <motion.span
            className="mb-0.5 h-4 w-1 rounded-full bg-gray-300/60"
            initial={{ opacity: 0.6, y: 0 }}
            animate={{ opacity: 0, y: -20 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        )}
      </AnimatePresence>
      {/* Candle body */}
      <div className={`h-8 w-1.5 rounded-t-sm ${lit ? 'bg-blush-200' : 'bg-gray-200'}`} />
    </button>
  );
}

export default function CakeScene({ onNext }: { onNext: () => void }) {
  const [candles, setCandles] = useState<boolean[]>(() => Array.from({ length: 7 }, () => true));
  const [wished, setWished] = useState(false);

  const blow = (i: number) => {
    setCandles((prev) => {
      const next = [...prev];
      next[i] = false;
      return next;
    });
  };

  const allOut = candles.every((c) => !c);

  return (
    <motion.div
      className={`dream-scene ${allOut ? 'dream-night' : 'dream-rose'} relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-6 py-12`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
    >
      <Starfield count={allOut ? 50 : 15} color={allOut ? 'white' : 'rgba(184,142,255,0.5)'} />
      {allOut && <FloatingParticles count={12} emojis={['✨', '⭐', '💫']} />}

      <div className="relative z-10 text-center">
        <motion.p
          className="font-display text-3xl font-semibold drop-shadow-sm sm:text-4xl"
          animate={{ color: allOut ? '#fff' : '#ff6b9d' }}
        >
          {content.cake.prompt} 🎂
        </motion.p>

        {/* Cake */}
        <div className="relative mt-10 flex flex-col items-center">
          {/* Candles row */}
          <div className="flex flex-wrap justify-center gap-1 px-4" style={{ maxWidth: '250px' }}>
            {candles.map((lit, i) => (
              <Candle key={i} lit={lit} onToggle={() => blow(i)} index={i} />
            ))}
          </div>

          {/* Age topper keeps the birthday feeling without a crowded forest of candles */}
          <motion.div
            className="mb-2 font-display text-4xl font-bold text-rose-500 drop-shadow-[0_4px_10px_rgba(255,105,160,.35)] sm:text-5xl"
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            {String(content.age)[0]} <span className="text-amber-400">&</span> {String(content.age)[1]}
          </motion.div>

          {/* Cake body */}
          <div className="relative mt-1">
            {/* Top tier */}
            <div className="relative h-14 w-48 rounded-t-2xl bg-gradient-to-b from-blush-200 to-blush-300 shadow-md sm:w-64">
              {/* Frosting drips */}
              <div className="absolute -top-1 left-0 flex w-full justify-around">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="h-3 w-4 rounded-b-full bg-cream-100" style={{ height: `${8 + (i % 3) * 4}px` }} />
                ))}
              </div>
            </div>
            {/* Bottom tier */}
            <div className="h-16 w-64 rounded-b-2xl bg-gradient-to-b from-blush-300 to-blush-400 shadow-lg sm:w-80">
              {/* Decorations */}
              <div className="flex h-full items-center justify-center gap-3 text-lg">
                {['🌸', '🎀', '✨', '🌸', '🎀'].map((e, i) => (
                  <span key={i}>{e}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {allOut && !wished && (
            <motion.p
              className="mt-8 font-display text-3xl text-white drop-shadow-lg sm:text-4xl"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              onAnimationComplete={() => setWished(true)}
            >
              ✨ {content.cake.wishMade}
            </motion.p>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {wished && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
            >
              <p className="mt-3 font-hand text-2xl text-white/90 drop-shadow sm:text-3xl">{content.cake.hope}</p>
              <div className="mt-8">
                <SceneButton onClick={onNext} variant="dark">
                  {content.cake.button} →
                </SceneButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
