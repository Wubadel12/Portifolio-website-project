import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';

type Photo = (typeof content.photos.images)[number];

function Polaroid({ photo, index, rotate, onOpen }: { photo: Photo; index: number; rotate: number; onOpen: () => void }) {
  return (
    <motion.button
      type="button"
      onClick={onOpen}
      className="relative bg-white p-2 pb-8 text-left shadow-xl outline-none focus-visible:ring-4 focus-visible:ring-pink-300/70"
      style={{ rotate: `${rotate}deg` }}
      initial={{ opacity: 0, y: 55, rotate: rotate * 2 }}
      animate={{ opacity: 1, y: 0, rotate }}
      transition={{ delay: index * 0.16, type: 'spring', stiffness: 120, damping: 14 }}
      whileHover={{ scale: 1.045, rotate: 0, zIndex: 10 }}
      whileTap={{ scale: 0.97 }}
      aria-label={`Open photo ${index + 1}`}
    >
      <div className="aspect-[4/5] w-[132px] overflow-hidden rounded-[2px] bg-pink-100 sm:w-44">
        <img src={photo.src} alt={content.name} className="h-full w-full object-cover" loading="lazy" />
      </div>
      <p className="mt-2 text-center font-hand text-sm font-semibold text-rose-700/85">{photo.caption}</p>
    </motion.button>
  );
}

export default function PhotoScene({ onNext }: { onNext: () => void }) {
  const [selected, setSelected] = useState<Photo | null>(null);

  return (
    <motion.div
      className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden dream-scene dream-rose px-4 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={12} emojis={['✨', '🌸', '💫', '💕']} />

      <div className="relative z-10 w-full max-w-2xl text-center">
        <motion.p
          className="font-display text-3xl font-semibold text-rose-800 drop-shadow-sm sm:text-4xl"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {content.photos.title} 💕
        </motion.p>
        <motion.p
          className="mx-auto mt-2 max-w-md font-body text-sm font-medium text-purple-900/80 sm:text-base"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {content.photos.subtitle}
        </motion.p>

        <div className="mx-auto mt-9 flex max-w-xl flex-wrap items-center justify-center gap-5 sm:gap-7">
          {content.photos.images.map((photo, index) => (
            <Polaroid
              key={photo.src}
              photo={photo}
              index={index}
              rotate={[-7, 5, -3][index]}
              onOpen={() => setSelected(photo)}
            />
          ))}
        </div>

        <motion.p
          className="mt-5 font-hand text-lg text-rose-700/75"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
        >
          tap a photo ✨
        </motion.p>

        <motion.div
          className="mt-7"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.05 }}
        >
          <SceneButton onClick={onNext}>{content.photos.button} →</SceneButton>
        </motion.div>
      </div>

      <AnimatePresence>
        {selected && (
          <motion.div
            className="fixed inset-0 z-[100] flex items-center justify-center bg-[#28152d]/80 p-5 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelected(null)}
          >
            <motion.div
              className="relative max-h-[88vh] max-w-[92vw] rounded-3xl bg-white/95 p-3 shadow-2xl"
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(event) => event.stopPropagation()}
            >
              <img src={selected.src} alt={content.name} className="max-h-[78vh] max-w-[86vw] rounded-2xl object-contain" />
              <p className="py-2 text-center font-hand text-xl font-semibold text-rose-700">{selected.caption}</p>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="absolute -right-3 -top-3 flex h-11 w-11 items-center justify-center rounded-full bg-white text-rose-700 shadow-lg"
                aria-label="Close photo"
              >
                <X size={22} />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
