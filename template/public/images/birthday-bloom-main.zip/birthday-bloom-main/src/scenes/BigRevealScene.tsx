import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content } from '@/content';
import FloatingParticles from '@/components/FloatingParticles';
import SceneButton from '@/components/SceneButton';
import { bigCelebration } from '@/components/confetti';

export default function BigRevealScene({ onNext }: { onNext: () => void }) {
  const [phase, setPhase] = useState<'ready' | 'count' | 'reveal'>('ready');
  const [count, setCount] = useState(3);

  useEffect(() => {
    if (phase !== 'count') return;
    if (count === 0) {
      setPhase('reveal');
      bigCelebration();
      return;
    }
    const t = setTimeout(() => setCount((c) => c - 1), 900);
    return () => clearTimeout(t);
  }, [phase, count]);

  return (
    <motion.div
      className="relative flex min-h-[100dvh] items-center justify-center overflow-hidden dream-scene dream-sunset"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <FloatingParticles count={16} emojis={['🎉', '🎀', '✨', '💫', '🌸', '🎈']} />

      <div className="relative z-10 text-center">
        <AnimatePresence mode="wait">
          {phase === 'ready' && (
            <motion.div
              key="ready"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
            >
              <p className="font-display text-4xl text-white drop-shadow-lg sm:text-5xl">
                {content.bigReveal.ready}
              </p>
              <div className="mt-9">
                <SceneButton onClick={() => setPhase('count')} variant="gold">
                  Ready? Let’s begin ✨
                </SceneButton>
              </div>
            </motion.div>
          )}

          {phase === 'count' && (
            <motion.div key="count" exit={{ opacity: 0, scale: 1.5 }}>
              <AnimatePresence mode="wait">
                <motion.p
                  key={count}
                  className="font-display text-[8rem] font-bold text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.6)]"
                  initial={{ opacity: 0, scale: 0.3 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.5 }}
                  transition={{ duration: 0.4 }}
                >
                  {count === 0 ? '🎉' : count}
                </motion.p>
              </AnimatePresence>
            </motion.div>
          )}

          {phase === 'reveal' && (
            <motion.div
              key="reveal"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 14 }}
            >
              <motion.p
                className="font-display text-3xl font-bold text-white drop-shadow-[0_0_20px_rgba(255,107,157,0.8)] sm:text-5xl"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                🎀 {content.bigReveal.headline} 🎀
              </motion.p>
              <motion.p
                className="mt-6 font-hand text-5xl text-white drop-shadow-lg sm:text-6xl"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.6 }}
              >
                {content.name}
              </motion.p>
              <motion.div
                className="mt-10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2, duration: 0.5 }}
              >
                <SceneButton onClick={onNext} variant="gold">
                  {content.bigReveal.button} →
                </SceneButton>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
