// ╔══════════════════════════════════════════════════════════════════╗
// ║  PERSONALIZE THE BIRTHDAY SURPRISE HERE                          ║
// ╚══════════════════════════════════════════════════════════════════╝

export const content = {
  name: 'Rodas',
  age: 20,

  opening: {
    greeting: 'Hey you...',
    subgreeting: 'I made something for you.',
    button: 'Start the surprise',
  },

  countdown: {
    wait: 'Wait...',
    almostForgot: 'I almost forgot something...',
    reveal: `YOU'RE TURNING 20!!!`,
    nowStart: 'Okay... NOW we can start.',
    button: 'Continue',
  },

  bigReveal: {
    ready: 'Ready?',
    headline: 'HAPPY 20TH BIRTHDAY',
    button: 'Keep going',
  },

  pickOne: {
    intro: 'Okay, birthday girl...',
    prompt: 'Pick one',
    cards: [
      { emoji: '🌸', message: "You're officially allowed to be spoiled today." },
      { emoji: '🎀', message: "Someone thinks you're pretty awesome." },
      { emoji: '🦋', message: 'Your birthday luck has been activated.' },
    ],
    button: 'Continue',
  },

  garden: {
    title: 'A tiny birthday garden just for you',
    flowers: [
      { message: 'You deserve a beautiful day.' },
      { message: "Don't forget to smile today." },
      { message: '20 looks good on you.' },
      { message: 'Today is officially your day.' },
      { message: 'Something lovely is coming your way.' },
      { message: 'You make the world a little brighter.' },
    ],
    button: 'Continue',
  },

  butterflies: {
    prompt: 'Catch one...',
    messages: [
      'Make a wish.',
      'Enjoy your day.',
      'Smile.',
      'Something special is waiting...',
      'Okay... one more smile for me?',
    ],
    button: 'Continue',
  },

  photos: {
    title: 'A little space for you',
    subtitle: 'Some of my favorite pictures of the birthday girl 💕',
    button: 'Continue',
    images: [
      { src: '/photos/rodas-1.jpg', caption: 'okayyy, look at you 🎀' },
      { src: '/photos/rodas-2.jpg', caption: 'this one is actually so pretty ✨✨' },
      { src: '/photos/rodas-3.jpg', caption: 'that smile tho 🤍' },
      { src: '/photos/rodas-5.jpg', caption: 'you look good here ' },
      { src: '/photos/rodas-4.jpg', caption: 'yeah… this one is my favorite 🤍' },
    ],
  },

  envelope: {
    prompt: "There's something I actually wanted to tell you...",
    letter: `Happy 20th birthday, birthday girl! 🎀

Well... you're finally 20 😂. I hope you have an amazing day and get everything you wished for.

I hope this new year of your life brings you a lot of happiness, good memories, and maybe a little less trouble .

Keep being your cute, funny, slightly childish self. Don't change that part of you. 🤍

And yeah, I hope you have the best birthday today. You really deserve it.

Happy birthday again, birthday girl. 🎂💕

— from someone who is definitely not admitting how much he likes talking to you 👀`,
    button: 'Continue',
  },

  oneMoreThing: {
    okay: 'Okay...',
    thatsAll: "That's all.",
    dots: '...',
    actuallyNo: 'Actually, no.',
    oneMore: "There's one more thing.",
    button: 'Open it',
  },

  gift: {
    label: 'Your last present',
    surprise: `A whole year of being 20 — and every reason to make it wonderful.\n\nOpen every day like it's a gift. 💕`,
    button: 'Continue',
  },

  cake: {
    prompt: 'Make a wish',
    wishMade: 'Wish made.',
    hope: 'I hope it comes true.',
    button: 'Continue',
  },

  finale: {
    happyBirthday: 'Happy Birthday 💕',
    welcomeTo: 'Welcome to 20.',
    hopeLine: 'I hope this year gives you a thousand reasons to smile.',
    enjoyLine: 'Enjoy your day, birthday girl.',
    madeFor: 'Made especially for you.',
  },

  music: {
    label: 'Play the birthday soundtrack',
    url: '/music/birthday.mp3',
  },

  easterEgg: {
    found: 'Okay... you found the secret',
    message: 'You have a knack for finding hidden things. 20 is going to be a good year for you.',
  },
};

export type Content = typeof content;
